import React from 'react';
import CasesBanner from '../components/cases/cases-banner/cases-banner';
import RecentCases from '../components/cases/recent-cases/recent-cases';

const ESG = () => {
  return (
    <div>
      <CasesBanner />
      <RecentCases />
    </div>
  )
}

export default ESG;
